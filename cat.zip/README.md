# Catinder

Welcome to **Catinder** - a simple, fun, and interactive Tinder-like app, but with cats! 🐱

## Features
- **Swipe Right** to like a cat
- **Swipe Left** to pass
- Discover adorable cats and find your purrfect match!

## Technologies Used
- **HTML5** for structure
- **CSS** for styling
- **JavaScript** for interactivity

## Feedback
We'd love to hear your thoughts! Send your feedback to: [oriolfibla@iesmontsia.org](mailto:oriolfibla@iesmontsia.org)

Hope you enjoy using Catinder! 😺
